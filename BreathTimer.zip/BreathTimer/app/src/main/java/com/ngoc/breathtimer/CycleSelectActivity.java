package com.ngoc.breathtimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class CycleSelectActivity extends Activity {

    private int cycles = 10;
    private TextView tvCycles;
    private int inhale, hold, exhale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cycle_select);

        inhale = getIntent().getIntExtra("inhale", 4);
        hold = getIntent().getIntExtra("hold", 4);
        exhale = getIntent().getIntExtra("exhale", 4);

        TextView tvPattern = findViewById(R.id.tvPattern);
        tvPattern.setText("Nhịp thở: " + inhale + " : " + hold + " : " + exhale);

        tvCycles = findViewById(R.id.tvCycles);
        tvCycles.setText(String.valueOf(cycles));

        findViewById(R.id.btnMinus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cycles > 1) {
                    cycles--;
                    tvCycles.setText(String.valueOf(cycles));
                }
            }
        });

        findViewById(R.id.btnPlus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cycles++;
                tvCycles.setText(String.valueOf(cycles));
            }
        });

        findViewById(R.id.btnStart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CycleSelectActivity.this, BreathActivity.class);
                intent.putExtra("inhale", inhale);
                intent.putExtra("hold", hold);
                intent.putExtra("exhale", exhale);
                intent.putExtra("cycles", cycles);
                startActivity(intent);
            }
        });
    }
}
